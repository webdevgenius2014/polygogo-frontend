'use client';
import React, { useEffect, useState } from 'react';
import styles from '../styles/styles.module.scss'
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Link from 'next/link'
import * as Yup from 'yup';
interface UserSignupForm {
    emailOrPhone: string
    password: string  
}
type Props = {
    isShowPass?: boolean;
    setIsShowPass: (val: boolean) => void;    
};
const LoginSignupForm : React.FC<Props> = ({ isShowPass=false, setIsShowPass}) =>{    
    const [ispassVisibility, setPasswordVisibility]=useState(false);    
    const validateEmail = (email: string | undefined) => {        
        var isValid = false;       
        if(email){
            isValid= Yup.string().email().isValidSync(email);
        }
        return isValid;
    };     
    const validatePhone = (phone: number | undefined) => {
        return Yup.number().integer().positive().test(
           (phone) => {
             return (phone && phone.toString().length >= 8 && phone.toString().length <= 14) ? true : false;
           }
         ).isValidSync(phone);
    };
    const validationSchema = Yup.object().shape({
        emailOrPhone: Yup.string()
            .required('Email / Phone is required')
            .test('emailOrPhone', 'Email / Phone is invalid', (value) => { 
                if(validateEmail(value)===true || validatePhone(parseInt(value ?? '0'))===true){
                    setIsShowPass(true);
                }
                return validateEmail(value) || validatePhone(parseInt(value ?? '0'));
            }
        ),
        password: Yup.string()            
            .required('Please Enter your password')                        
            .matches(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
                "Password must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
        ),
       
    });
    const {
        register,        
        formState,
        handleSubmit,
        reset,
    } = useForm<UserSignupForm>({resolver: yupResolver(validationSchema)}); 
    const { errors } = formState;     
    const onSubmit = (data: UserSignupForm) => {
        console.log(JSON.stringify(data, null, 2));
    };
    const viewPassword=()=>{
        setPasswordVisibility(!ispassVisibility);
    }
    return(<>
        <form className={styles.form} id="login_form" onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group mb-4">
                <label className={`${styles.label}`}>Email or Phone Number</label>
                <input 
                    type="text"                       
                    {...register("emailOrPhone")} 
                    placeholder="Enter your email or phone number" 
                    className={`form-control ${styles.input_field} ${styles.input_mail} ${errors.emailOrPhone ? 'is-invalid' : ''}`}                        
                />                
                {errors.emailOrPhone?.message && <p className={'text-danger mt-2'}>{errors.emailOrPhone?.message}</p>}               
            </div>
            {isShowPass===true?(<>
                <div className="form-group mb-4">
                    <label className={`${styles.label}`}>Password</label>
                    <div className='position-relative'>
                        <input
                            type={ispassVisibility?"text":"password"}
                            {...register('password')} 
                            className={`form-control ${styles.input_field} ${styles.input_lock} ${errors.password ? 'is-invalid' : ''}`} 
                        />
                        {ispassVisibility?(
                            <span className={styles.pass_eye} onClick={()=>viewPassword()}><img src="/icons/eye.svg" alt="eye" width="23" /></span>
                        ):(
                            <span className={styles.pass_eye} onClick={()=>viewPassword()}>  <img src="/icons/eye-slash.svg" alt="eye" width="23" /></span>                            
                        )} 
                    </div>               
                    {errors.password?.message && <p className={'text-danger mt-2'}>{errors.password?.message}</p>}               
                </div>
                <div className='text-end'><Link href="/auth/forgot-password">Frogot Password?</Link></div>                                           
            </>):('')} 
            <button type='submit' disabled={formState.isSubmitting} className={`mt-3 ${styles.btn} ${styles.btn_primary}`}>
                {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                <span>{isShowPass?'Sign Up':'Continue with email'}</span>
            </button> 
        </form>        
    </>);
};
export default LoginSignupForm;
