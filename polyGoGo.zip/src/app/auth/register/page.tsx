'use client';
import Image from 'next/image'
import styles from '../../styles/styles.module.scss'
import SocialMideiaLogin from '../login-buttons'
import LoginSignupForm from '../login-signup'
import Link from 'next/link'
import React, { useEffect, useState } from 'react';
// import {testAPI} from '../../services/user.service';
import axiosInstance from '../../services/user.service';

export default function Register() {
  const [isFromShow, setIsFromShow]= useState(false);
  const [isShowPass, setIsShowPass] = useState(false);
  const [currentImage, setCurrentImage]= useState("social-media-login");
  useEffect(()=>{
    const getData = async () => {
      try {
        const response = await axiosInstance.get('bulbasaur'); // Replace with your API endpoint  
        // Handle the response data here
        console.log(response.data);
      } catch (error) {
        // Handle the error here
        console.error(error);
      }
    }; 
    getData();   
  }, [])
  useEffect(()=>{
    if(isShowPass===false && isFromShow===false){
      setCurrentImage('social-media-login')
    }else if(isShowPass===false && isFromShow===true){
      setCurrentImage('email-login')
    }else{
      setCurrentImage('password-lock')
    }
  },[isShowPass, isFromShow])
  return (
    <main className={styles.main}>
        <div className={styles.container}>
          <div className={`d-flex ${styles.box_wrap}`}>
            <div className={styles.box_one}>
              <div className={styles.title_image}>
                <Image
                  src="/PolygogoBlack.png"
                  width={176}
                  height={35}
                  alt="Poly go go Black"                
                />
              </div>
              <div className={styles.form_wrap}>
                <h2 className={`text-center mb-3 ${styles.heading_one}`}>Give company a try. It"’"s free.</h2>                
                <p className={`text-center ${styles.fs_sm} ${styles.mw_356}`} style={{marginBottom: '2.938rem'}}>Grow with tools for texting customers, getting reviews, and making sales. No credit card required.</p>
                <SocialMideiaLogin />
                {isFromShow?(
                  <LoginSignupForm isShowPass={isShowPass} setIsShowPass={setIsShowPass} />
                ):<div style={{marginTop: '4.584rem'}}></div>}
                <p className='text-center mb-0'>You can also continue with <span className={styles.link} onClick={()=>setIsFromShow(true)}>Email</span></p>
                <p className={`text-center ${styles.fs_sm} ${styles.mw_356} ${styles.mtb_4}`}>By continuing, you agree that you have read and accept Polygogo <Link href="/" className={`${styles.link}`}>Terms of Service </Link> and <Link href="/" className={`${styles.link}`}>Privacy Policy.</Link></p>
                <p className='text-center'>Already have an account? <Link href="/auth/login" className={`text-uppercase ${styles.link}`}>Sign In</Link></p>
              </div>
              <div className={styles.copyright}>© 2023 Polygogo. All rights reserved.</div>
            </div>
            <div className={styles.box_two} style={{backgroundImage:'url(/images/pattern.png)'}}>
                <div className={`text-center ${styles.heading_wrap}`}>
                  <h1 className={styles.heading_one}>Join 100,000+ businesses using Polygogo to grow</h1>
                </div>
                <Image
                  src={`/images/${currentImage}.png`}
                  width={579}
                  height={482}
                  alt={currentImage}
                  className='mw-100'
                />
            </div>
          </div>
        </div>
    </main>
  )
}