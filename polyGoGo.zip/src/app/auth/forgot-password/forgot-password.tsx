'use client';
import React, { useEffect, useState } from 'react'
import styles from '../../styles/styles.module.scss'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as Yup from 'yup';
interface ForgotPasswordForm {
    emailOrPhone: string
    code: string  
}
type Props = {
    isShowPass?: boolean;
    setIsShowPass: (val: boolean) => void;   
};
const ForgotPasswordForm : React.FC<Props> = ({ isShowPass=false, setIsShowPass }) =>{
    const validateEmail = (email: string | undefined) => {        
        var isValid = false;       
        if(email){
            isValid= Yup.string().email().isValidSync(email);
        }
        return isValid;
    };     
    const validatePhone = (phone: number | undefined) => {
        return Yup.number().integer().positive().test(
           (phone) => {
             return (phone && phone.toString().length >= 8 && phone.toString().length <= 14) ? true : false;
           }
         ).isValidSync(phone);
    };
    const validationSchema = Yup.object().shape({
        emailOrPhone: Yup.string()
            .required('Email / Phone is required')
            .test('emailOrPhone', 'Email / Phone is invalid', (value) => { 
                if(validateEmail(value)===true || validatePhone(parseInt(value ?? '0'))===true){
                    setIsShowPass(true);
                }
                return validateEmail(value) || validatePhone(parseInt(value ?? '0'));
            }
        ),        
        code: Yup.string().min(4).max(6).required('Please enter verification code'),
       
    });
    const {
        register,        
        formState,
        handleSubmit,
        reset,
    } = useForm<ForgotPasswordForm>({resolver: yupResolver(validationSchema)}); 
    const { errors } = formState;     
    const onSubmit = (data: ForgotPasswordForm) => {
        console.log(JSON.stringify(data, null, 2));
    };
    
    return(<>
        <form className={styles.form} id="login_form" onSubmit={handleSubmit(onSubmit)}>            
            {isShowPass!==true?(<>
                <div className="form-group mb-4">
                    <label className={`${styles.label}`}>Email or Phone Number</label>
                    <input 
                        type="text"                       
                        {...register("emailOrPhone")} 
                        placeholder="Enter your email or phone number" 
                        className={`form-control ${styles.input_field} ${styles.input_mail} ${errors.emailOrPhone ? 'is-invalid' : ''}`}                        
                    />                
                    {errors.emailOrPhone?.message && <p className={'text-danger mt-2'}>{errors.emailOrPhone?.message}</p>}               
                </div>                                                        
            </>):(
                <div className="form-group mb-4">
                    <label className={`${styles.label}`}>Enter Code</label>                    
                    <input
                        type="text"
                        {...register('code')} 
                        placeholder="Enter code" 
                        className={`form-control ${styles.input_field} ${styles.input_code} ${errors.code ? 'is-invalid' : ''}`} 
                    />            
                    {errors.code?.message && <p className={'text-danger mt-2'}>{errors.code?.message}</p>}               
                </div>
            )} 
            <button type='submit' disabled={formState.isSubmitting} className={`mt-3 ${styles.btn} ${styles.btn_primary}`}>
                {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                <span>{isShowPass?'Sign In':'Continue with email'}</span>
            </button> 
        </form>        
    </>);
};
export default ForgotPasswordForm;
